# Polybrutus D47 — Provenance and responsible research disclosure

**Scientific human author:** Gabriel St-Pierre, independent researcher.
**Material AI assistance:** ChatGPT (Astra) helped exact checking, verification, manuscript, archival and publication; AI is not scientific author.

**Direct predecessor only:** Topbrutus/polybrutus-d46@v0.1.0; scientific commit 2181c7a3b744c784d377c8910c91d08985b84b65; DOI 10.5281/zenodo.24416489; original deterministic certificate SHA-256 4b5a26d2df42443eef2fe2e2015dd3042fa31051edb7e283ca9cd25eeaa3899d.

**Complete authentic ancestry:** original D46 frozen source ZIP 2363484 bytes, 30 entries, SHA-256 59779a2bd99b75cb6fb3edcb059819ed12a1fb10402c30079402e464d5ffbf18, CRC PASS, stored at prior/d46/frozen_scientific_tag_v0.1.0.zip with all older archives. Parent cert copied byte-identically to prior/d46/results/certificate_d46.json. The D46 ZIP differs from Git LF blobs only in CRLF formatting for .gitattributes, .gitignore and requirements.txt; after line-ending normalization their contents match the tag; all other entries are byte-identical. The ZIP itself is kept untouched.

**References:** D46 DOI 10.5281/zenodo.24416489 (derived-from direct parent); D7 DOI 10.5281/zenodo.24407952 (historical origin, not immediate parent).
**QA:** dimension and graph multiplicity keywords computed from current certificate, no copied 31D terms; separate references and structured DOI relationship required.

**Scientific interpretation:** One exact synthetic Euclidean labelled metric and one independently selected ideal weighted graph; no demonstrated physical extra dimensions, measured hertz, particle physics, new universal theorem or independent human peer review.
**Licenses:** MIT software, CC BY 4.0 manuscript.
