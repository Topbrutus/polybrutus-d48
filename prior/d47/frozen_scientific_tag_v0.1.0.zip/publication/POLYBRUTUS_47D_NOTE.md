# Polybrutus 47D: Exact 52-point Euclidean metric and a forty-onefold ideal graph mode

**Gabriel St-Pierre** — Independent researcher
**21 November 2026**
**Exact mathematical case study / scientific preprint**
**AI assistance:** OpenAI ChatGPT (Astra) materially assisted exact rational calculations, two independent programs, scientific writing and publication; AI is not a scientific author.

## Abstract

We construct an exact labelled squared-distance Euclidean metric for 52 norm-one points by appending one perpendicular unit point to immutable Polybrutus 46D [1]. The 1275 original labelled squared pairs are conserved and 51 new squared distances are 2 at unit radius, for 1326 distinct unordered labelled pairs. The centered Euclidean Gram is positive semidefinite, exact rank 47, proving minimal affine realization dimension 47 for this synthetic metric. For a separately stipulated ideal complete weighted graph with scalar unit masses and edge weights w_ij=1/d_ij², two exact rational verifiers find Laplacian eigenvalue 26 of multiplicity 41 and 51/2 of multiplicity 4. These model modes are not measured physical frequencies.

## 1. Immutable scientific ancestry and conservative completion

The only scientific parent is St-Pierre, Polybrutus 46D [1], DOI 10.5281/zenodo.24416489, GitHub frozen tag v0.1.0 at commit 2181c7a3b744c784d377c8910c91d08985b84b65. Original complete D46 source is embedded as prior/d46/frozen_scientific_tag_v0.1.0.zip (2363484 bytes, 30 entries, ZIP SHA-256 59779a2bd99b75cb6fb3edcb059819ed12a1fb10402c30079402e464d5ffbf18, CRC PASS), with every earlier nested source archive. Original D46 certificate is copied byte-identically, SHA-256 4b5a26d2df42443eef2fe2e2015dd3042fa31051edb7e283ca9cd25eeaa3899d. Both exact programs authenticate these originals.

For original unit vectors p_i (i=1,...,51), embed q_i=(p_i,0) and append an independent perpendicular unit vector q_52. All 1275 predecessor labelled pairs are unchanged; each new squared distance ||q_52-q_i||²=2. Therefore C(52,2)=1326=1275+51. This is a conservative Euclidean extension of one specified metric.

## 2. Exact Gram and labelled-distance checks

Seven canonical rational unit points produce a rank-three Gram block; five centered regular-simplex unit points produce an independent rank-four block. Forty additional perpendicular axes contribute rank 40, giving full unit-diagonal Gram G rank 3+4+40=47, PSD by explicit vectors. The exact squared-distance matrix D_ij=2-2G_ij, D_ii=0 and projector H=I-11ᵀ/52 give centered Gram B=-HDH/2=HGH, PSD of rank 47. An inherited antipodal pair places the origin in the affine hull.

All 1326 labelled squared distances were exhaustively reconstructed independently. At R=1 the counts for k=4d²/R² are 4:6, 7:2, 8:1295, 9:3, 10:10, 12:6, 13:2, 16:2, totaling 1326, with exact squared-distance sum 10655/4. A histogram alone is insufficient: all 1275 original labelled pairs are compared against the authentic D46 certificate.

## 3. Separately stipulated weighted graph and falsification

An ideal complete graph with scalar unit masses and w_ij=1/d_ij² gains 51 new edges with weight 1/2. Its Laplacian has block form L47=[[L46+I51/2,-1_51/2],[-1_51ᵀ/2,51/2]]. Its characteristic-polynomial recurrence is chi52(z)=z(z-26)chi51(z-1/2)/(z-1/2), giving chosen-model expression z(z-26)^41(z-51/2)^4*f6(z-45/2), with f6 inherited from the original seven-point graph.

Exact nullities from two separately implemented programs give eigenvalue 26 multiplicity 41 and eigenvalue 51/2 multiplicity 4. The primary SymPy Gram implementation and independent fractions.Fraction distance implementation agree on all 1326 labels, 1275 old labels, centered Euclidean rank, Laplacian rank and deterministic certificate. Four primary negative controls reject corruption, duplication, nonorthogonal tilt and histogram-preserving relabeling.

## 4. Scope, reproducibility and bibliography

This is one explicit synthetic Euclidean metric and one freely chosen ideal graph. Orthogonal extensions and graph joining are established mathematical techniques. No measured extra spacetime dimensions, particle physics, physical frequencies, new universal theorem or independent human peer review are claimed. Reproduce with sympy==1.14.0, src/verify_d47.py and tests/independent_d47.py. The ZIP contains original complete D46 science; its three files differing from Git tag checkout are CRLF-only configurations, not scientific alterations.

Zenodo must preserve structured related_identifiers isDerivedFrom -> 10.5281/zenodo.24416489, and a separate textual references list citing direct parent D46 [1] and historic Polybrutus 7D [2]; keywords forty-seven and forty-onefold must derive from current verified certificate.

## References

[1] St-Pierre, Gabriel (2026). Polybrutus 46D: Exact 51-Point Euclidean Metric and Fortyfold Ideal Graph Mode. Zenodo. DOI: 10.5281/zenodo.24416489. https://doi.org/10.5281/zenodo.24416489

[2] St-Pierre, Gabriel (2026). Polybrutus 7D: An Exact Twelve-Point Orthogonal Completion, the 12-35-37 Identity, and an Oscillator Model. Zenodo. DOI: 10.5281/zenodo.24407952. https://doi.org/10.5281/zenodo.24407952

[3] St-Pierre, Gabriel (2026). Polybrutus D46 original scientific frozen tag v0.1.0. GitHub: https://github.com/Topbrutus/polybrutus-d46/tree/v0.1.0 ; scientific commit 2181c7a3b744c784d377c8910c91d08985b84b65. Unmodified original full science ZIP embedded.
