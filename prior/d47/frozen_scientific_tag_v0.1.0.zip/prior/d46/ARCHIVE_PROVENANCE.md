# Frozen source D46 — immutable scientific parent

Original scientific Git tag: https://github.com/Topbrutus/polybrutus-d46/tree/v0.1.0
Commit: 2181c7a3b744c784d377c8910c91d08985b84b65
Scientific parent DOI: 10.5281/zenodo.24416489
Complete original ZIP: frozen_scientific_tag_v0.1.0.zip
ZIP bytes: 2363484
ZIP SHA-256: 59779a2bd99b75cb6fb3edcb059819ed12a1fb10402c30079402e464d5ffbf18
ZIP entries: 30, CRC verified
Original deterministic cert: results/certificate_d46.json
Certificate SHA-256: 4b5a26d2df42443eef2fe2e2015dd3042fa31051edb7e283ca9cd25eeaa3899d
Older scientific sources are nested unchanged inside this complete D46 source ZIP.
The original archive is preserved exactly; three plain-text Git files use CRLF in the ZIP but LF after Git checkout, a line-ending-only difference.
