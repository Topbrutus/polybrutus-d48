# Polybrutus D47 — Verified bibliography

The author and titles were checked against the public Zenodo record on 2026-11-21. These are earlier project publications, not independent peer review.

## [1] Immediate direct parent

St-Pierre, Gabriel (2026). Polybrutus 46D: Exact 51-Point Euclidean Metric and Fortyfold Ideal Graph Mode. Zenodo. DOI 10.5281/zenodo.24416489. https://doi.org/10.5281/zenodo.24416489
Frozen scientific source: https://github.com/Topbrutus/polybrutus-d46/tree/v0.1.0 ; commit 2181c7a3b744c784d377c8910c91d08985b84b65. All 1275 predecessor distances are preserved.

## [2] Historical project context

St-Pierre, Gabriel (2026). Polybrutus 7D: An Exact Twelve-Point Orthogonal Completion, the 12-35-37 Identity, and an Oscillator Model. Zenodo. DOI 10.5281/zenodo.24407952. https://doi.org/10.5281/zenodo.24407952

## Zenodo metadata contract

Exactly one related_identifiers entry isDerivedFrom -> 10.5281/zenodo.24416489; references contains both textual citations above. Required keywords: affine Euclidean dimension forty-seven; forty-onefold ideal eigenvalue. Both fields must be publicly verified after publication.
