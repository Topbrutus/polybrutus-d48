#!/usr/bin/env python3
"""Offline gate, source of truth: new exact certificate and parent DOI."""
from pathlib import Path
import json
R=Path(__file__).resolve().parents[1]
c=json.loads((R/'results/certificate_d47.json').read_text())
m=json.loads((R/'publication/zenodo_metadata_blueprint.json').read_text())
assert c['status']=='PASS'
assert c['dimension']==m['scientific_dimension']==47
assert c['vertices']==m['norm_one_vertices']==52
assert c['pairs']==m['exact_labelled_squared_pairs']==1326
assert c['affine_rank']==c['centered_gram_rank']==47
assert c['eigenvalue_26_multiplicity']==m['model_eigenvalue_26_multiplicity']==41
assert c['eigenvalue_51_over_2_multiplicity']==m['model_eigenvalue_51_over_2_multiplicity']==4
assert c['parent_doi']==m['scientific_parent_doi']=='10.5281/zenodo.24416489'
assert m['related_identifiers']==[{'identifier':'10.5281/zenodo.24416489','relation':'isDerivedFrom','resource_type':'publication-preprint','scheme':'doi'}]
assert len(m['keywords'])==9
assert 'affine Euclidean dimension forty-seven' in m['keywords']
assert 'forty-onefold ideal eigenvalue' in m['keywords']
assert len(m['references'])==2
assert '10.5281/zenodo.24416489' in m['references'][0]
assert '10.5281/zenodo.24407952' in m['references'][1]
bad=('thirty-one','twenty-fivefold','forty-six','fortyfold','forty-five','thirty-ninefold')
assert not any(x in str(m['keywords']) for x in bad)
doc=(R/'publication/POLYBRUTUS_47D_NOTE.md').read_text(encoding='utf8')
assert all(x in doc for x in ('## References','10.5281/zenodo.24416489','10.5281/zenodo.24407952'))
print('D47_ZENODO_KEYWORDS_REFERENCES_PARENT_RELATION_GATE_PASS')
