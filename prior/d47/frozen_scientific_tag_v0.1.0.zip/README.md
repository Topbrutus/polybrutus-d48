# Polybrutus 47D — Exact 52-point Euclidean metric and forty-onefold ideal graph mode

**Human scientific author:** Gabriel St-Pierre, independent researcher.
**AI assistance:** OpenAI ChatGPT (Astra) materially assisted exact arithmetic, independent checking programs, manuscript, GitHub and Zenodo publication; AI is not a scientific author.

## Fully reproducible exact construction

- 52 norm-one vertices, exactly 1326 unordered labelled squared pair distances.
- 1275/1275 D46 predecessor labels unchanged, plus 51 new squared distances equal 2R².
- Exact Euclidean Gram rank 47 and centered Gram rank 47; minimum affine realization dimension 47.
- Histogram k=4d²/R²: 4:6, 7:2, 8:1295, 9:3, 10:10, 12:6, 13:2, 16:2; exact sum at R=1: 10655/4.
- Separate chosen ideal complete graph w_ij=R²/d_ij² with scalar unit masses: eigenvalue 26 multiplicity 41; eigenvalue 51/2 multiplicity 4.
- Two independently implemented exact arithmetic programs (SymPy Gram and Fraction distance rule), 4/4 primary adversarial negative controls.

Reproduce on Python 3.12:

    python -m pip install sympy==1.14.0
    python src/verify_d47.py
    python tests/independent_d47.py
    python src/check_zenodo_metadata.py

Both mathematical programs agree on the exact deterministic SHA-256 of results/certificate_d47.json.

## Authenticated source and lineage

**Only direct scientific parent:** [Polybrutus D46 v0.1.0](https://github.com/Topbrutus/polybrutus-d46/tree/v0.1.0), scientific commit 2181c7a3b744c784d377c8910c91d08985b84b65, DOI [10.5281/zenodo.24416489](https://doi.org/10.5281/zenodo.24416489).
Original complete published D46 scientific tag ZIP is frozen at prior/d46/frozen_scientific_tag_v0.1.0.zip, SHA-256 59779a2bd99b75cb6fb3edcb059819ed12a1fb10402c30079402e464d5ffbf18, containing all earlier nested science. Original certificate D46 is byte-identical under prior/d46/results/certificate_d46.json, SHA-256 4b5a26d2df42443eef2fe2e2015dd3042fa31051edb7e283ca9cd25eeaa3899d. Both programs authenticate ZIP SHA/CRC and certificate contents.

## Manuscript and metadata safeguards

[Specification](SPECIFICATION_D47.md) | [Constructive proof](PREUVE_D47.md) | [Provenance](PROVENANCE.md) | [References](REFERENCES.md) | [Scientific PDF](publication/POLYBRUTUS_47D_NOTE.pdf) | [Metadata blueprint](publication/zenodo_metadata_blueprint.json).

Zenodo QA requires dimension-specific forty-seven and forty-onefold keywords, isDerivedFrom structured DOI relationship to D46 and *separate two-entry textual bibliography* citing D46 as direct parent and D7 as historical source. CI validates those before scientific tag; public API must confirm after Zenodo publication.

**Scope:** One exact synthetic Euclidean labelled metric and one independently selected ideal weighted graph; no demonstrated physical extra dimensions, measured hertz, particle physics, new universal theorem or independent human peer review.
**Licenses:** MIT for software; CC BY 4.0 for manuscript.
