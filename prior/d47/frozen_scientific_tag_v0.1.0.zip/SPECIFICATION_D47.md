# Polybrutus 47D — Exact rational Euclidean labelled-distance metric

**Source:** D46 immutable scientific tag v0.1.0, commit 2181c7a3b744c784d377c8910c91d08985b84b65, DOI 10.5281/zenodo.24416489; original ZIP SHA-256 59779a2bd99b75cb6fb3edcb059819ed12a1fb10402c30079402e464d5ffbf18; original certificate SHA-256 4b5a26d2df42443eef2fe2e2015dd3042fa31051edb7e283ca9cd25eeaa3899d. All older source archives nested in the unmodified D46 ZIP.

## Conservative Euclidean extension

For each of 51 predecessor norm-one vectors p_i, set q_i=(p_i,0), then append q_52=e_48 orthogonal to all old vectors. Original 1275 unordered labelled squared distances are unchanged. Each new squared distance equals 2R². Thus C(52,2)=1326=1275+51.

Rational Gram G has a canonical seven-point rank-three block, independent centered five-unit-simplex rank-four block, and 40 mutually orthogonal unit axes: rank(G)=3+4+40=47, all diagonal entries one and PSD by explicit vector realization. D_ij=2-2G_ij; H=I-11ᵀ/52; B=-HDH/2=HGH is PSD rank 47. An inherited antipodal pair guarantees origin in affine hull; minimal affine Euclidean realization dimension is 47, with 48 storage coordinates.

Histogram k=4d²/R²: {4:6,7:2,8:1295,9:3,10:10,12:6,13:2,16:2}, summing to 1326. Sum of squared distances at R=1: 10655/4.

## Chosen ideal weighted graph

Choose unit scalar masses and symmetric weights w_ij=1/d_ij². Adding vertex 52 gives Laplacian L47 = [[L46+I51/2,-1_51/2],[-1_51ᵀ/2,51/2]]. The exact graph-join recurrence is chi52(z)=z(z-26)chi51(z-1/2)/(z-1/2). The inherited seven-point factor f6(z)=chiP7(z)/z yields chi52(z)=z(z-26)^41(z-51/2)^4*f6(z-45/2).

Exact nullities verify eigenvalue 26 multiplicity 41, eigenvalue 51/2 multiplicity 4. These are dimensionless properties of the stipulated graph, not observed frequencies.

**Metadata gate:** parent DOI 10.5281/zenodo.24416489, words forty-seven / forty-onefold, two bibliographic references. **Limit:** One exact synthetic Euclidean labelled metric and one independently selected ideal weighted graph; no demonstrated physical extra dimensions, measured hertz, particle physics, new universal theorem or independent human peer review.
